<script setup lang='ts'>

import { ref } from "vue"

interface UseCounterOptions {
  min?: number
  max?: number
}

/**
 * Implement the composable function
 * Make sure the function works correctly
*/

const currentValue = ref(0)
function useCounter(initialValue = 0, options: UseCounterOptions = {}) {
  currentValue.value = initialValue
  return {
    inc: () => currentValue.value++,
    dec: () => currentValue.value--,
    reset: () => currentValue.value = initialValue,
    count: currentValue.value,
  }

}

const { count, inc, dec, reset } = useCounter(0, { min: 0, max: 10 })

</script>

<template>
  <p>Count: {{ currentValue }}</p>
  <button @click="inc">
    inc
  </button>
  <button @click="dec">
    dec
  </button>
  <button @click="reset()">
    reset
  </button>
</template>
