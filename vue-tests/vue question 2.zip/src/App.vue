<template>
  <div>
    <p>{{ count }}</p>
    <p>{{ plusOne }}</p>
  </div>
</template>

<script setup lang="ts">
  import { ref, computed } from "vue"

  const count = ref(1)
  const plusOne = computed({
    get(value) {
      return value !== undefined ? count.value + value : count.value
    },
    set(value) {
      count.value++
      return value
    }
  })

  /**
  * Make the `plusOne` writable.
  * So that we can get the result `plusOne` to be 3, and `count` to be 2.
  */

  plusOne.value++

</script>


